#pragma once
#include "Programmer.h"
class P_Keyboard :
	public Programmer
{
public:
	P_Keyboard();
	~P_Keyboard();
	void walk();
	void attack();
	void display();
	void getHit(float);
	void setStyle(ALLEGRO_BITMAP*);
	void setHp(float);
	void setDead(bool);
	void setPosX(float);
	void setPosY(float);
	void setShow(int);
	string getName();
	float getSpeed();
	ALLEGRO_BITMAP *getStyle();
	bool cekDead();
	float getPosX();
	float getPosY();
	int getShow();
};

