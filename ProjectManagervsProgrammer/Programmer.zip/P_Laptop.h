#pragma once
#include "Programmer.h"
class P_Laptop :
	public Programmer
{
public:
	P_Laptop();
	~P_Laptop();
	//void strike(); no idea so far.
	void walk();
	void attack();
	void getHit(float);
	void display();
	void setStyle(ALLEGRO_BITMAP*);
	void setHp(float);
	void setDead(bool);
	void setPosX(float);
	void setPosY(float);
	void setShow(int);
	string getName();
	float getSpeed();
	ALLEGRO_BITMAP *getStyle();
	bool cekDead();
	float getPosX();
	float getPosY();
	int getShow();
};

