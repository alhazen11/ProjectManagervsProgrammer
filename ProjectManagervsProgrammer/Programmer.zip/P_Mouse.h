#pragma once
#include "Programmer.h"
class P_Mouse :
	public Programmer
{
public:
	P_Mouse();
	~P_Mouse();
	//void throwed(); this particular thing too
	void walk();
	void attack();
	void getHit(float);
	void display();
	void setStyle(ALLEGRO_BITMAP*);
	void setHp(float);
	void setDead(bool);
	void setPosX(float);
	void setPosY(float);
	void setShow(int);
	string getName();
	float getSpeed();
	ALLEGRO_BITMAP *getStyle();
	bool cekDead();
	float getPosX();
	float getPosY();
	int getShow();
};

