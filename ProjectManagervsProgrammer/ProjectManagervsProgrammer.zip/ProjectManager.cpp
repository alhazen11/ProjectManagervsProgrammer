#include "ProjectManager.h"



ProjectManager::ProjectManager()
{
}


ProjectManager::~ProjectManager()
{
}

void ProjectManager::Attack()
{
}

string ProjectManager::set_Style(string)
{
	return string();
}

void ProjectManager::getHit(float)
{
}

void ProjectManager::getHit(float, float)
{
}

string ProjectManager::get_Name()
{
	return NULL;
}

float ProjectManager::get_Speed()
{
	return NULL;
}

bool ProjectManager::getDead()
{
	return false;
}

void ProjectManager::set_Hp(float)
{
}

void ProjectManager::isDead(bool)
{
}

ALLEGRO_BITMAP * ProjectManager::get_Style()
{
	return nullptr;
}

void ProjectManager::set_Cor_x(float)
{
}

void ProjectManager::set_Cor_y(float)
{
}


void ProjectManager::display()
{
}

void ProjectManager::set_show(int)
{
}

int ProjectManager::get_show()
{
	return 0;
}

float ProjectManager::get_Cor_x()
{
	return 0.0f;
}

float ProjectManager::get_Cor_y()
{
	return 0.0f;
}
