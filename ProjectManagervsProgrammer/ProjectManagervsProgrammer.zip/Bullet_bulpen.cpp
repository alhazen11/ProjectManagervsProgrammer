#include "Bullet_bulpen.h"



Bullet_bulpen::Bullet_bulpen()
{
}


Bullet_bulpen::~Bullet_bulpen()
{
}
