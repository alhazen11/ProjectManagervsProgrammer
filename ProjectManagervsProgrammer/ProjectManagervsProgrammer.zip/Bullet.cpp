#include "Bullet.h"



Bullet::Bullet()
{
}


Bullet::~Bullet()
{
}
