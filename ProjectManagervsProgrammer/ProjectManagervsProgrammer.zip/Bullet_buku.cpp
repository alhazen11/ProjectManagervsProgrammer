#include "Bullet_buku.h"



Bullet_buku::Bullet_buku()
{
}


Bullet_buku::~Bullet_buku()
{
}
