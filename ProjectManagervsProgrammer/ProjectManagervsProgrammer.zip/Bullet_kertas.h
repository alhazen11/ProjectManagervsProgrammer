#pragma once
#include "Bullet.h"
class Bullet_kertas :
	public Bullet
{
public:
	Bullet_kertas();
	~Bullet_kertas();
};

