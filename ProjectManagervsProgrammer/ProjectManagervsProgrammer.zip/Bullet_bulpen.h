#pragma once
#include "Bullet.h"
class Bullet_bulpen :
	public Bullet
{
public:
	Bullet_bulpen();
	~Bullet_bulpen();
};

