#include "Bullet_kertas.h"



Bullet_kertas::Bullet_kertas()
{
}


Bullet_kertas::~Bullet_kertas()
{
}
