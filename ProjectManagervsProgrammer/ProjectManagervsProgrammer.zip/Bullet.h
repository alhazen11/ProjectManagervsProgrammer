#pragma once
class Bullet
{
public:
	Bullet();
	~Bullet();
	virtual void display() = 0;
};

