#pragma once
#include "Bullet.h"
class Bullet_buku :
	public Bullet
{
public:
	Bullet_buku();
	~Bullet_buku();
};

